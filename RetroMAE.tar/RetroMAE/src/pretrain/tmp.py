
from pysenal import read_jsonline_lazy

f_name = "/home/huangjiayue/04_SimCSE/SimCSE/openai-pid2embedding.json"
set_pid = set()
for dict_ in read_jsonline_lazy(f_name):

    pid = dict_["pid"]
    set_pid.add(pid)

print(len(set_pid))

