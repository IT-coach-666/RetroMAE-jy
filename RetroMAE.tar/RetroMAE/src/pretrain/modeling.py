import logging

import torch
from pretrain.arguments import ModelArguments
from pretrain.enhancedDecoder import BertLayerForDecoder
from torch import nn
from transformers import BertForMaskedLM, AutoModelForMaskedLM
from transformers.modeling_outputs import MaskedLMOutput

logger = logging.getLogger(__name__)


class RetroMAEForPretraining(nn.Module):
    def __init__(
            self,
            bert: BertForMaskedLM,
            model_args: ModelArguments,
    ):
        super(RetroMAEForPretraining, self).__init__()
        # jy: 已初始化的 BertForMaskedLM 类(/transformers/models/bert/modeling_bert.py 中定义)
        self.lm = bert
        # jy: decoder 的 embedding 设置为与 bert 的 embedding 相同, 为:
        """
        BertEmbeddings(
          (word_embeddings): Embedding(21128, 768, padding_idx=0)
          (position_embeddings): Embedding(512, 768)
          (token_type_embeddings): Embedding(2, 768)
          (LayerNorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
          (dropout): Dropout(p=0.1, inplace=False)
        )
        """
        self.decoder_embeddings = self.lm.bert.embeddings
        # jy: 初始化 BertLayerForDecoder 类 (./enhancedDecoder.py 中定义)
        self.c_head = BertLayerForDecoder(bert.config)
        self.c_head.apply(self.lm._init_weights)

        self.cross_entropy = nn.CrossEntropyLoss()

        self.model_args = model_args

    def forward(self,
                encoder_input_ids, encoder_attention_mask, encoder_labels,
                decoder_input_ids, decoder_attention_mask, decoder_labels):
        """
        encoder_input_ids: 输入文本的 token id 列表(含首末 special token);
                           维度为 [batch_size, max_len]
        encoder_attention_mask: 维度同上, 值全为 1
        encoder_labels: 维度同上, 记录那些会被 mask 掉的 token id (后续供预测时校验)
                        注意-jy-IMP: encoder 端的 mask 仅仅在该参数中得到体现;
        decoder_input_ids: 
        decoder_attention_mask: 维度为 [batch_size, max_len, max_len], 即 decoder 端
                                注意力权重得分 mask 矩阵
        decoder_labels: 为 decoder_input_ids 中首末 special token 置为 -100 的结果
        """
        import pdb; pdb.set_trace()
        # jy: self.lm 为: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        #     调用该类返回得到的结果为 MaskedLMOutput 类, 包含如下属性:
        #     loss: tensor(2.0674, device='cuda:0', grad_fn=<NllLossBackward0>)
        #     logits: 维度为 [batch_size, max_len, 21128]
        #     hidden_states: 长度为 13 的元组, 元组中存储每一层输出的向量, 维度为 [batch_size, max_len, 768]
        #     attentions: None
        lm_out: MaskedLMOutput = self.lm(
            encoder_input_ids, encoder_attention_mask,
            labels=encoder_labels,
            output_hidden_states=True,
            return_dict=True
        )
        # jy: 取最后一层的 cls token 对应的向量结果, 维度为 [batch_size, 1, 768]
        cls_hiddens = lm_out.hidden_states[-1][:, :1] 

        # jy: self.decoder_embeddings 即 bert 的 embedding 模型类, 此处即对 decoder 端
        #     的输入进行 embedding 编码, 得到的 decoder_embedding_output 维度为:
        #     [batch_size, max_len, 768]
        decoder_embedding_output = self.decoder_embeddings(input_ids=decoder_input_ids)
        # jy: decoder_embedding_output[:, 1:] 的维度为 [batch_size, max_len-1, 768], 表示
        #     decoder 端的输入编码向量化后不取首个 [CLS] token 的向量, 只取其它 token 的
        #     向量; 而 sentence_embedding 即表示 encoder 端的 cls 向量输出结果; 以下将两
        #     者进行拼接, 组成 decoder 端的最终输入向量, 维度为: [batch_size, max_len, 768]
        hiddens = torch.cat([cls_hiddens, decoder_embedding_output[:, 1:]], dim=1)

        # jy: 单独获取 decoder 端的位置 id 信息, 得到的 decoder_position_ids 维度为
        #     [1, max_len], 值为从 0 到 max_len-1;
        decoder_position_ids = self.lm.bert.embeddings.position_ids[:, :decoder_input_ids.size(1)]
        # jy: 获取位置编码向量, 维度为 [1, max_len, 768]
        decoder_position_embeddings = self.lm.bert.embeddings.position_embeddings(decoder_position_ids)  # B L D
        # jy: 将位置编码向量融入到 cls_hiddens 中, 使得得到的 query 包含位置编码信息
        query = decoder_position_embeddings + cls_hiddens

        # jy: decoder_attention_mask 的维度为 [batch_size, max_len, max_len]
        #     扩充为后得到的 matrix_attention_mask 维度为 [batch_size, 1, max_len, max_len]
        matrix_attention_mask = self.lm.get_extended_attention_mask(
            decoder_attention_mask,
            decoder_attention_mask.shape,
            decoder_attention_mask.device
        )

        # jy: self.c_head 为已初始化的 BertLayerForDecoder 类 (./enhancedDecoder.py 中)
        #     此处传入 q、k、v 和注意力权重得分 mask 矩阵, 得到的 hiddens 维度为:
        #     [batch_size, max_len, 768]
        # jy: 注意: BertLayerForDecoder 类其实就是 BertLayer 的改写 (将传入的参数
        #     由 hidden_states 改为传入 query、key、value); BertLayer 指的是 BertModel
        #     (/transformers/models/bert/modeling_bert.py 中定义) 中的层级类, Bert 模型
        #     中会使用 12 层, 此处只使用一层 BertLayerForDecoder 作为 Decoder 进行解码;
        hiddens = self.c_head(query=query,
                              key=hiddens,
                              value=hiddens,
                              attention_mask=matrix_attention_mask)[0]
        # jy: decoder_labels 维度为 [batch_size, max_len], 记录 decoder 端要预测的 token id
        #     (除 special token 不需要预测外, 其它 token 均需要预测, 因为 mask 掉的其实是针
        #     对注意力矩阵中的注意力得分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩
        #     阵, 实际上 decoder 的输入的 id 不会被 mask); mlm_loss 方法对 hiddens 向量进行
        #     线性转换, 转换后得到的向量维度中, 每个位置上的 token 对应的向量维度与词表大小
        #     相同, 因此可基于该向量与该位置上的真实 token id 计算预测 loss 得到的
        #     pred_scores 维度为 [batch_size, max_len, 21128]
        #     loss 如: tensor(6.3621, device='cuda:0', grad_fn=<NllLossBackward0>)
        pred_scores, loss = self.mlm_loss(hiddens, decoder_labels)

        return (loss + lm_out.loss,)

    def mlm_loss(self, hiddens, labels):
        """
        对 hiddens 向量进行线性转换, 转换后得到的向量维度中, 每个位置上的 token 对应的
        向量维度与词表大小相同, 因此可基于该向量与该位置上的真实 token id 计算预测 loss
        传入参数:
        hiddens: 维度为 [batch_size, max_len, 768]
        labels: 维度为 [batch_size, max_len], 记录 decoder 端要预测的 token id
                (除 special token 不需要预测外, 其它 token 均需要预测, 因为 mask 掉的其实是针
                对注意力矩阵中的注意力得分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩
                阵, 实际上 decoder 的输入的 id 不会被 mask)
        """
        # jy: self.lm 为: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        #     self.lm.cls 为已初始化的 BertOnlyMLMHead 类, 该类作用: 对 hiddens 向量进行线性转换 (从
        #     [batch_size, max_len, 768] 维转换为 [batch_size, max_len, 21128] 维)、激活函数激
        #     活、layernorm 处理, 因此得到的 pred_scores 维度为 [batch_size, max_len, 21128]
        pred_scores = self.lm.cls(hiddens)
        # jy: 计算线性转换后的 token id 向量分布与 labels 标签的 token id 的交叉熵损失得分
        masked_lm_loss = self.cross_entropy(
            # jy: 维度为 [batch_size * max_len, 21128]
            pred_scores.view(-1, self.lm.config.vocab_size),
            # jy: 维度为 [batch_size * max_len]
            labels.view(-1)
        )
        return pred_scores, masked_lm_loss

    def save_pretrained(self, output_dir: str):
        self.lm.save_pretrained(output_dir)

    @classmethod
    def from_pretrained(
            cls, model_args: ModelArguments,
            *args, **kwargs
    ):
        """
        自定义了 from_pretrained 方法
        """
        # jy: 已初始化的 BertForMaskedLM 类(/transformers/models/bert/modeling_bert.py 中定义)
        hf_model = AutoModelForMaskedLM.from_pretrained(*args, **kwargs)
        # jy: 初始化当前类并返回
        model = cls(hf_model, model_args)
        return model
