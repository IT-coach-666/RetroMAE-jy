import logging
import os
from typing import Dict, Optional

import torch
from transformers import Trainer

logger = logging.getLogger(__name__)


# jy: 继承自 Trainer 类(/transformers/trainer.py 中定义), 该类的初始化方法
#     在父类中定义
class PreTrainer(Trainer):

    def log(self, logs: Dict[str, float]) -> None:
        """
        重写父类的 log 方法(传参不变): 在原方法中补充了 logs["step"] 的值


        Log `logs` on the various objects watching training.

        Subclass and override this method to inject custom behavior.

        Args:
            logs (`Dict[str, float]`):
                The values to log.
        """
        # jy: 在父类方法的基础上补充了 logs["step"], 其它部分的代码逻辑不变;
        logs["step"] = self.state.global_step
        if self.state.epoch is not None:
            logs["epoch"] = round(self.state.epoch, 2)

        output = {**logs, **{"step": self.state.global_step}}
        self.state.log_history.append(output)
        self.control = self.callback_handler.on_log(self.args, self.state, self.control, logs)

    def _save(self, output_dir: Optional[str] = None):
        """
        重写父类的 _save 方法(传参也做了改变: 去除了 state_dict 参数定义)
        改写前后保存的模型相关文本基本不变
        """
        output_dir = output_dir if output_dir is not None else self.args.output_dir
        os.makedirs(output_dir, exist_ok=True)
        logger.info(f"Saving model checkpoint to {output_dir}")

        # Save a trained model and configuration using `save_pretrained()`.
        # They can then be reloaded using `from_pretrained()`
        # jy: 保存模型
        if not hasattr(self.model, 'save_pretrained'):
            logger.info("Trainer.model is not a `PreTrainedModel`, only saving its state dict.")
            state_dict = self.model.state_dict()
            torch.save(state_dict, os.path.join(output_dir, "pytorch_model.bin"))
        else:
            self.model.save_pretrained(output_dir)

        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(output_dir)

        # Good practice: save your training arguments together with the trained model
        torch.save(self.args, os.path.join(output_dir, "training_args.bin"))
