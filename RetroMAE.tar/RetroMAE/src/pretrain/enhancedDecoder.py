'''
The codes are modified based on huggingface transformers library.
该脚本中的大部分代码参考 /transformers/models/bert/modeling_bert.py 中的同名类
进行定义, 并做适当修改;
'''

import math
from typing import Optional, Tuple

import torch
import torch.utils.checkpoint
from torch import nn
from transformers.modeling_utils import (
    apply_chunking_to_forward,
    find_pruneable_heads_and_indices,
    prune_linear_layer,
)
from transformers.models.bert.modeling_bert import BertIntermediate, BertOutput, BertSelfOutput
from transformers.utils import (
    logging,
)

logger = logging.get_logger(__name__)


class BertSelfAttention(nn.Module):
    """
    参考 /transformers/models/bert/modeling_bert.py 中的同名类, 除了 forward 方法外,
    其它代码完全相同;
    """
    def __init__(self, config, position_embedding_type=None):
        super().__init__()
        if config.hidden_size % config.num_attention_heads != 0 and not hasattr(config, "embedding_size"):
            raise ValueError(
                f"The hidden size ({config.hidden_size}) is not a multiple of the number of attention "
                f"heads ({config.num_attention_heads})"
            )
        # jy: 12
        self.num_attention_heads = config.num_attention_heads
        # jy: 768 / 12 = 64
        self.attention_head_size = int(config.hidden_size / config.num_attention_heads)
        # jy: 768
        self.all_head_size = self.num_attention_heads * self.attention_head_size

        # jy: q, k, v 均为: Linear(in_features=768, out_features=768, bias=True)
        self.query = nn.Linear(config.hidden_size, self.all_head_size)
        self.key = nn.Linear(config.hidden_size, self.all_head_size)
        self.value = nn.Linear(config.hidden_size, self.all_head_size)

        # jy: Dropout(p=0.1, inplace=False)
        self.dropout = nn.Dropout(config.attention_probs_dropout_prob)
        # jy: 'absolute'
        self.position_embedding_type = position_embedding_type or getattr(
            config, "position_embedding_type", "absolute"
        )
        if self.position_embedding_type == "relative_key" or \
                self.position_embedding_type == "relative_key_query":
            self.max_position_embeddings = config.max_position_embeddings
            self.distance_embedding = nn.Embedding(2 * config.max_position_embeddings - 1,
                                                   self.attention_head_size)
        # jy: False
        self.is_decoder = config.is_decoder

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(
        self,
        query,
        key,
        value,
        attention_mask: Optional[torch.FloatTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        encoder_hidden_states: Optional[torch.FloatTensor] = None,
        encoder_attention_mask: Optional[torch.FloatTensor] = None,
        past_key_value: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.Tensor]:
        """
        原 /transformers/models/bert/modeling_bert.py 中的该方法的传入参数没有 
        query, key 和 value 这三项, 而是传入 hidden_states, 对应的 q、k、v 向
        量则是通过 hidden_states 构造得到
        query: 维度为 [batch_size, max_len, 768], 每个 token 对应的向量均为 encoder 端
               cls 输出向量经过 decoder 端再进行 embedding 编码融入位置信息的结果
        key:   维度为 [batch_size, max_len, 768], 是以下两个向量进行拼接后的结果:
               1) decoder 端的输入编码向量化后不取首个 [CLS] token 的向量, 只取其
                  它 token 的向量;
               2) encoder 端的 cls 向量输出结果
        value: 与 key 完全相同
        """
        # jy: 原本是基于 hidden_states 构建得到 mixed_query_layer, 现改为基于传入
        #     的 query
        mixed_query_layer = self.query(query)

        # jy: False
        # If this is instantiated as a cross-attention module, the keys
        # and values come from an encoder; the attention mask needs to be
        # such that the encoder's padding tokens are not attended to.
        is_cross_attention = encoder_hidden_states is not None

        if is_cross_attention and past_key_value is not None:
            # reuse k,v, cross_attentions
            key_layer = past_key_value[0]
            value_layer = past_key_value[1]
            attention_mask = encoder_attention_mask
        # jy: False
        elif is_cross_attention:
            key_layer = self.transpose_for_scores(self.key(encoder_hidden_states))
            value_layer = self.transpose_for_scores(self.value(encoder_hidden_states))
            attention_mask = encoder_attention_mask
        # jy: None
        elif past_key_value is not None: 
            # jy: 原本是基于 hidden_states 构建得到 key_layer, 现改为基于传入的 key
            key_layer = self.transpose_for_scores(self.key(key))
            # jy: 原本是基于 hidden_states 构建得到 value_layer, 现改为基于传入的 value
            value_layer = self.transpose_for_scores(self.value(value))
            key_layer = torch.cat([past_key_value[0], key_layer], dim=2)
            value_layer = torch.cat([past_key_value[1], value_layer], dim=2)
        else:
            # jy: 原本是基于 hidden_states 构建得到 key_layer, 现改为基于传入的 key
            #     self.key(hidden_states) 表示线性处理, 转换为 key 向量, 维度
            #     不变: [batch_size, max_len, 768]
            #     此处进一步调用 transpose_for_scores 方法, 将维度转换为:
            #     [batch_size, 12, max_len, 64]
            key_layer = self.transpose_for_scores(self.key(key))
            # jy: 原本是基于 hidden_states 构建得到 value_layer, 现改为基于传入的 value
            #     同理, 得到的 value_layer 维度为: [batch_size, 12, max_len, 64]
            value_layer = self.transpose_for_scores(self.value(value))

        # jy: 同理, 得到的 query_layer 维度为: [batch_size, 12, max_len, 64]
        query_layer = self.transpose_for_scores(mixed_query_layer)

        if self.is_decoder:
            # if cross_attention save Tuple(torch.Tensor, torch.Tensor) of all cross attention key/value_states.
            # Further calls to cross_attention layer can then reuse all cross-attention
            # key/value_states (first "if" case)
            # if uni-directional self-attention (decoder) save Tuple(torch.Tensor, torch.Tensor) of
            # all previous decoder key/value_states. Further calls to uni-directional self-attention
            # can concat previous decoder key/value_states to current projected key/value_states (third
            # "elif" case) if encoder bi-directional self-attention `past_key_value` is always `None`
            past_key_value = (key_layer, value_layer)

        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))

        if self.position_embedding_type == "relative_key" or \
                self.position_embedding_type == "relative_key_query":
            # jy: 获取序列长度, 与原版本中的有点差异, 但获取的结果相同
            seq_length = query.size()[1]
            # jy: position_ids_l 与原版本中的有点差异
            position_ids_l = torch.arange(seq_length, dtype=torch.long, device=query.device).view(-1, 1)
            position_ids_r = torch.arange(seq_length, dtype=torch.long, device=query.device).view(1, -1)
            distance = position_ids_l - position_ids_r
            positional_embedding = self.distance_embedding(distance + self.max_position_embeddings - 1)
            positional_embedding = positional_embedding.to(dtype=query_layer.dtype)  # fp16 compatibility

            if self.position_embedding_type == "relative_key":
                relative_position_scores = torch.einsum("bhld,lrd->bhlr", query_layer, positional_embedding)
                attention_scores = attention_scores + relative_position_scores
            elif self.position_embedding_type == "relative_key_query":
                relative_position_scores_query = torch.einsum("bhld,lrd->bhlr", query_layer,
                                                              positional_embedding)
                relative_position_scores_key = torch.einsum("bhrd,lrd->bhlr", key_layer, positional_embedding)
                attention_scores = attention_scores + relative_position_scores_query + \
                                   relative_position_scores_key

        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        if attention_mask is not None:
            # Apply the attention mask is (precomputed for all layers in BertModel forward() function)
            attention_scores = attention_scores + attention_mask

        # Normalize the attention scores to probabilities.
        attention_probs = nn.functional.softmax(attention_scores, dim=-1)

        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        attention_probs = self.dropout(attention_probs)

        # Mask heads if we want to
        if head_mask is not None:
            attention_probs = attention_probs * head_mask

        context_layer = torch.matmul(attention_probs, value_layer)

        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(new_context_layer_shape)

        outputs = (context_layer, attention_probs) if output_attentions else (context_layer,)

        if self.is_decoder:
            outputs = outputs + (past_key_value,)
        return outputs


class BertAttention(nn.Module):
    """
    该类同样参考自 /transformers/models/bert/modeling_bert.py 中的同名类, 主要
    对 forward 方法进行了传入参数的改写与适配;
    """
    def __init__(self, config, position_embedding_type=None):
        super().__init__()
        # jy: 当前脚本中自定义的 BertSelfAttention 自注意力机制类 (含自定义的 q, k, v),
        #     该自定义的自注意力机制类参考自 /transformers/models/bert/modeling_bert.py 中
        #     的同名类, 主要对 forward 方法进行了传入参数的改写与适配;
        self.self = BertSelfAttention(config, position_embedding_type=position_embedding_type)
        # jy: 初始化 BertSelfOutput 类 (/transformers/models/bert/modeling_bert.py 中), 该
        #     类的作用主要是对 hidden_states 进行线性变换 (从 768 维变为 768 维)、dropout、残
        #     差链接和 layernorm 处理
        self.output = BertSelfOutput(config)
        self.pruned_heads = set()

    # jy: 该方法暂未被使用
    def prune_heads(self, heads):
        if len(heads) == 0:
            return
        heads, index = find_pruneable_heads_and_indices(
            heads, self.self.num_attention_heads, self.self.attention_head_size, self.pruned_heads
        )

        # Prune linear layers
        self.self.query = prune_linear_layer(self.self.query, index)
        self.self.key = prune_linear_layer(self.self.key, index)
        self.self.value = prune_linear_layer(self.self.value, index)
        self.output.dense = prune_linear_layer(self.output.dense, index, dim=1)

        # Update hyper params and store pruned heads
        self.self.num_attention_heads = self.self.num_attention_heads - len(heads)
        self.self.all_head_size = self.self.attention_head_size * self.self.num_attention_heads
        self.pruned_heads = self.pruned_heads.union(heads)

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.FloatTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        encoder_hidden_states: Optional[torch.FloatTensor] = None,
        encoder_attention_mask: Optional[torch.FloatTensor] = None,
        past_key_value: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.Tensor]:
        """
        传入参数: 原版本中有传入 hidden_states 参数, 此处修改为传如 query、key、value 参数
        query: 维度为 [batch_size, max_len, 768], 每个 token 对应的向量均为 encoder 端
               cls 输出向量经过 decoder 端再进行 embedding 编码融入位置信息的结果
        key:   维度为 [batch_size, max_len, 768], 是以下两个向量进行拼接后的结果:
               1) decoder 端的输入编码向量化后不取首个 [CLS] token 的向量, 只取其
                  它 token 的向量;
               2) encoder 端的 cls 向量输出结果
        value: 与 key 完全相同 
        """
        # jy: self.self 为已初始化的 BertSelfAttention 自注意力机制类, 该自定义的 
        #     自注意力机制类参考自 /transformers/models/bert/modeling_bert.py 中
        #     的同名类, 主要对 forward 方法进行了传入参数的改写与适配(由原先传入
        #     hidden_states 变为传入 query、key、value)
        self_outputs = self.self(
            # jy: 原版本中传入的是 hidden_states, 此处修改为 query, key, value
            query, key, value,
            attention_mask,
            head_mask,
            encoder_hidden_states,
            encoder_attention_mask,
            past_key_value,
            output_attentions,
        )
        # jy: 原版本是基于 hidden_states 进行残差连接, 此版本修改为基于传入的 query;
        #     对以上输出结果进行线性变换(从 768 维变为 768 维)、dropout、残差连
        #     接和 layernorm 处理, 得到结果向量维度为 [batch_size, max_len, 768]
        attention_output = self.output(self_outputs[0], query)
        # add attentions if we output them
        outputs = (attention_output,) + self_outputs[1:]  
        return outputs


class BertLayerForDecoder(nn.Module):
    """
    该类参考自 /transformers/models/bert/modeling_bert.py 中的 BertLayer 类;
    Bert 模型(BertModel 类)中会使用 12 个 BertLayer 类 (12 层), 而此处只使用
    一层 BertLayerForDecoder 作为 decoder 的网络架构;
    """
    def __init__(self, config):
        super().__init__()
        # jy: 0
        self.chunk_size_feed_forward = config.chunk_size_feed_forward
        self.seq_len_dim = 1
        # jy: 初始化 BertAttention 类 (在当前脚本中定义, 是对原 Bert 模型中的同名类的简单改写)
        self.attention = BertAttention(config)
        # jy: False
        self.is_decoder = config.is_decoder
        # jy: False
        self.add_cross_attention = config.add_cross_attention
        if self.add_cross_attention:
            if not self.is_decoder:
                raise ValueError(f"{self} should be used as a decoder model if cross attention is added")
            self.crossattention = BertAttention(config, position_embedding_type="absolute")
        # jy: 初始化 BertIntermediate 类 (/transformers/models/bert/modeling_bert.py 中), 主
        #     要作用是进行线性变换(将 hidden_states 从 768 维变换为 3072 维)和激活(套用指定
        #     的激活函数)
        self.intermediate = BertIntermediate(config)
        # jy: 初始化 BertOutput 类 (/transformers/models/bert/modeling_bert.py 中), 主要作用
        #     是对 hidden_states 做进一步的线性变换(从 3072 维变换为 768 维)、dropout、残差
        #     连接、layernorm 处理
        self.output = BertOutput(config)

    def forward(
            self,
            query: torch.Tensor,
            key: torch.Tensor,
            value: torch.Tensor,
            attention_mask: Optional[torch.FloatTensor] = None,
            head_mask: Optional[torch.FloatTensor] = None,
            encoder_hidden_states: Optional[torch.FloatTensor] = None,
            encoder_attention_mask: Optional[torch.FloatTensor] = None,
            past_key_value: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
            output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.Tensor]:
        """
        传入参数: 原版本中有传入 hidden_states 参数, 此处修改为传如 query、key、value 参数
        query: 维度为 [batch_size, max_len, 768], 每个 token 对应的向量均为 encoder 端
               cls 输出向量经过 decoder 端再进行 embedding 编码融入位置信息的结果
        key:   维度为 [batch_size, max_len, 768], 是以下两个向量进行拼接后的结果:
               1) decoder 端的输入编码向量化后不取首个 [CLS] token 的向量, 只取其
                  它 token 的向量; 
               2) encoder 端的 cls 向量输出结果
        value: 与 key 完全相同
        attention_mask: 维度为 [batch_size, 1, max_len, max_len], 反映 decoder 端
                        的注意力权重 mask 矩阵信息
        其余参数均为默认值
        """
        # jy: None
        # decoder uni-directional self-attention cached key/values tuple is at positions 1,2
        self_attn_past_key_value = past_key_value[:2] if past_key_value is not None else None
        # jy: 返回一个元组类型的数据, 其中第一个元素为 attention_output (经过自注意力机制得
        #     分处理后的隐层向量结果), 维度为: [batch_size, max_len, 768] 
        self_attention_outputs = self.attention(
            # jy: 原版本传入的是 hidden_states, 现传入的是 query, key, value
            query, key, value,
            attention_mask,
            head_mask,
            output_attentions=output_attentions,
            past_key_value=self_attn_past_key_value,
        )
        attention_output = self_attention_outputs[0]

        # if decoder, the last output is tuple of self-attn cache
        if self.is_decoder:
            outputs = self_attention_outputs[1:-1]
            present_key_value = self_attention_outputs[-1]
        else:
            # add self attentions if we output attention weights
            outputs = self_attention_outputs[1:] 

        cross_attn_present_key_value = None
        # jy: False
        if self.is_decoder and encoder_hidden_states is not None:
            if not hasattr(self, "crossattention"):
                raise ValueError(
                    f"If `encoder_hidden_states` are passed, {self} has to be instantiated with"
                     " cross-attention layers by setting `config.add_cross_attention=True`"
                )

            # cross_attn cached key/values tuple is at positions 3,4 of past_key_value tuple
            cross_attn_past_key_value = past_key_value[-2:] if past_key_value is not None else None
            cross_attention_outputs = self.crossattention(
                attention_output,
                attention_mask,
                head_mask,
                encoder_hidden_states,
                encoder_attention_mask,
                cross_attn_past_key_value,
                output_attentions,
            )
            attention_output = cross_attention_outputs[0]
            # add cross attentions if we output attention weights
            outputs = outputs + cross_attention_outputs[1:-1]  

            # add cross-attn cache to positions 3,4 of present_key_value tuple
            cross_attn_present_key_value = cross_attention_outputs[-1]
            present_key_value = present_key_value + cross_attn_present_key_value

        # jy: 调用 /transformers/pytorch_utils 中的 apply_chunking_to_forward 函数, 进行中间层线性
        #     变换后, 对输出结果再次线性变换、dropout、残差连接、layernorm 处理, 最终得
        #     到的 layer_output 维度为: [batch_size, max_len, 768]
        layer_output = apply_chunking_to_forward(
            # jy: 该类中自定义的方法
            self.feed_forward_chunk,
            # jy: 0
            self.chunk_size_feed_forward,
            # jy: 1
            self.seq_len_dim,
            # jy: 经过自注意力机制得分处理后的隐层向量结果, 维度为: [batch_size, max_len, 768]
            attention_output
        )
        outputs = (layer_output,) + outputs

        # if decoder, return the attn key/values as the last output
        if self.is_decoder:
            outputs = outputs + (present_key_value,)

        return outputs

    def feed_forward_chunk(self, attention_output):
        # jy: 进行线性变换(将 hidden_states 从 768 维变换为 3072 维)
        #     和激活(套用指定的激活函数)
        intermediate_output = self.intermediate(attention_output)
        # jy: 对 hidden_states 做进一步的线性变换(从 3072 维变换为 768
        #     维)、dropout、残差连接、layernorm 处理
        layer_output = self.output(intermediate_output, attention_output)
        return layer_output

