import logging

import torch
import torch.nn.functional as F
from pretrain.arguments import ModelArguments
from pretrain.enhancedDecoder import BertLayerForDecoder
from torch import nn
from transformers import BertForMaskedLM, AutoModelForMaskedLM
from transformers.modeling_outputs import MaskedLMOutput

logger = logging.getLogger(__name__)


class DupMAEForPretraining(nn.Module):
    def __init__(
            self,
            bert: BertForMaskedLM,
            model_args: ModelArguments,
    ):
        """
        初始化当前模型类, 在调用 from_pretrained 类方法时会执行该初始化方法;
        bert: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        model_args: 模型参数类
        """
        super(DupMAEForPretraining, self).__init__()
        # jy: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        self.lm = bert
        # jy: decoder 的 embedding 设置为与 bert 的 embedding 相同, 为:
        """
        BertEmbeddings(
	  (word_embeddings): Embedding(21128, 768, padding_idx=0)
	  (position_embeddings): Embedding(512, 768)
	  (token_type_embeddings): Embedding(2, 768)
	  (LayerNorm): LayerNorm((768,), eps=1e-12, elementwise_affine=True)
	  (dropout): Dropout(p=0.1, inplace=False)
	)
        """
        self.decoder_embeddings = self.lm.bert.embeddings
        # jy: 初始化 ./enhancedDecoder.py 中的 BertLayerForDecoder 类 (自定义的类)
        self.c_head = BertLayerForDecoder(bert.config)
        self.c_head.apply(self.lm._init_weights)
        # jy: 交叉熵损失
        self.cross_entropy = nn.CrossEntropyLoss()
        # jy: 参数类(含 bow_loss_weight, 默认值为 0.1)
        self.model_args = model_args

    def decoder_mlm_loss(self, sentence_embedding, decoder_input_ids, decoder_attention_mask, decoder_labels):
        """
        传入参数:
        sentence_embedding: 维度为 [batch_size, 768]
        decoder_input_ids: 原始输入文本的 token id 列表(含首末两个特殊字符)
                           维度为 [batch_size, max_len]
        decoder_attention_mask: 一段文本的注意力权重 mask 矩阵 (其中矩阵每一行的首末位置均
                                为 1, 对角线位置为 0, 即表明 special token 的相关注意力得分
                                均被 mask 掉, 其它 token 自身的注意力确保一定不会被 mask)
                                注意-jy-IMP: decoder 端的 mask 仅仅在该参数中得到体现
                                维度为 [batch_size, max_len, max_len]
        decoder_labels: 记录 decoder 端要预测的 token id (除 special token 不需要预测外, 其
                        它 token 均需要预测, 因为 mask 掉的其实是针对注意力矩阵中的注意力得
                        分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩阵, 实际上
                        decoder 的输入的 id 不会被 mask)
                        维度为 [batch_size, max_len]
        """

        # jy: decoder_input_ids.size(0) 即 batch_size 值; 以下操作即将 sentence_embedding
        #     的维度由 [batch_size, 768] 转变为 [batch_size, 1, 768]
        sentence_embedding = sentence_embedding.view(decoder_input_ids.size(0), 1, -1)
        # jy: self.decoder_embeddings 即 bert 的 embedding 模型类, 此处即对 decoder 端
        #     的输入进行 embedding 编码, 得到的 decoder_embedding_output 维度为:
        #     [batch_size, max_len, 768]
        decoder_embedding_output = self.decoder_embeddings(input_ids=decoder_input_ids)
        # jy: decoder_embedding_output[:, 1:] 的维度为 [batch_size, max_len-1, 768], 表示
        #     decoder 端的输入编码向量化后不取首个 [CLS] token 的向量, 只取其它 token 的
        #     向量; 而 sentence_embedding 即表示 encoder 端的 cls 向量输出结果; 以下将两
        #     者进行拼接, 组成 decoder 端的最终输入向量, 维度为: [batch_size, max_len, 768]
        hiddens = torch.cat([sentence_embedding, decoder_embedding_output[:, 1:]], dim=1)

        # jy: 基于 sentence_embedding (即 encoder 端 cls 输出向量, 维度为 [batch_size, 1, 768]) 构
        #     造 query_embedding, 维度为 [batch_size, max_len, 768]
        query_embedding = sentence_embedding.expand(hiddens.size(0), hiddens.size(1), hiddens.size(2))
        # jy: self.decoder_embeddings 即 bert 的 embedding 模型类, 使用该模型类进行编码会融入
        #     位置信息, 得到的 query 维度仍为 [batch_size, max_len, 768]
        query = self.decoder_embeddings(inputs_embeds=query_embedding)

        # jy: decoder_attention_mask 的维度为 [batch_size, max_len, max_len], 反映 decoder 端
        #     的注意力权重 mask 矩阵信息; self.lm 为已初始化的 BertForMaskedLM 类;
        #     经过以下转换后, matrix_attention_mask 的维度为 [batch_size, 1, max_len, max_len]
        matrix_attention_mask = self.lm.get_extended_attention_mask(
            decoder_attention_mask,
            decoder_attention_mask.shape,
            decoder_attention_mask.device
        )

        # jy: self.c_head 为已初始化的 BertLayerForDecoder 类 (./enhancedDecoder.py 中)
        #     此处传入 q、k、v 和注意力权重得分 mask 矩阵, 得到的 hiddens 维度为:
        #     [batch_size, max_len, 768]
        # jy: 注意: BertLayerForDecoder 类其实就是 BertLayer 的改写 (将传入的参数
        #     由 hidden_states 改为传入 query、key、value); BertLayer 指的是 BertModel
        #     (/transformers/models/bert/modeling_bert.py 中定义) 中的层级类, Bert 模型
        #     中会使用 12 层, 此处只使用一层 BertLayerForDecoder 作为 Decoder 进行解码;
        hiddens = self.c_head(query=query,
                              key=hiddens,
                              value=hiddens,
                              attention_mask=matrix_attention_mask)[0]
        # jy: decoder_labels 维度为 [batch_size, max_len], 记录 decoder 端要预测的 token id
        #     (除 special token 不需要预测外, 其它 token 均需要预测, 因为 mask 掉的其实是针
        #     对注意力矩阵中的注意力得分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩
        #     阵, 实际上 decoder 的输入的 id 不会被 mask); mlm_loss 方法对 hiddens 向量进行
        #     线性转换, 转换后得到的向量维度中, 每个位置上的 token 对应的向量维度与词表大小
        #     相同, 因此可基于该向量与该位置上的真实 token id 计算预测 loss 得到的
        #     pred_scores 维度为 [batch_size, max_len, 21128]
        #     loss 如: tensor(6.3621, device='cuda:0', grad_fn=<NllLossBackward0>)
        pred_scores, loss = self.mlm_loss(hiddens, decoder_labels)

        return loss

    def ot_embedding(self, logits, attention_mask):
        """
        max-pooling 操作提取一个句子中 other token 的特征, 得到的结果向量作
        为 bag of words 特征向量, 维度为: [batch_size, 21128]

        logits: 维度为 [batch_size, max_len-1, 21128], 即除了 [CLS] 之外的其它 token
                所组成的向量的维度
        attention_mask: 维度为 [batch_size, max_len-1], 即除了 [CLS] 之外的其它 token,
                        向量值均为 1
        """
        # jy: attention_mask.unsqueeze(-1) 得到的向量维度为 [batch_size, max_len-1, 1]
        #     经过以下处理后, 得到的 mask 的维度为 [batch_size, max_len-1, 1], 值均为 0
        mask = (1 - attention_mask.unsqueeze(-1)) * -1000
        # jy: 由于 mask 值均为 0, 因此 logits + mask 后的结果仍为 logits; 经以下在 dim=1
        #     维度进行 max 处理后(即 max-pooling 操作), 得到的 reps 的维度为 [batch_size, 21128]
        #     此时将 reps 作为句子中所有 token 的 bag of words 的特征向量
        reps, _ = torch.max(logits + mask, dim=1)
        # jy: 如果是要进行 avg-pooling 操作, 则:
        #reps = torch.sum(logits + mask, dim=1) / logits.size(1)
        return reps

    def decoder_ot_loss(self, ot_embedding, bag_word_weight):
        """
        ot_embedding: 维度为 [batch_size, 21128], 对 other token 的 embedding 进行 max-pooling 操
                      作, 提取一个句子中 other token 的特征, 得到的结果向量作为句子的 bag of words
                      特征向量
        bag_word_weight: 维度为: [batch_size, 21128], 存放一个句子中的 token id 在词表的
                         对应位置的权重; 总权重和为 1, 因此每个 token 的权重为 1/len(sentence)
        """
        # jy: 对 ot_embedding 进行归一化并取 log 结果, 经处理后得到的 input 维度仍
        #     为 [batch_size, 21128]
        input = F.log_softmax(ot_embedding, dim=-1)
        # jy: 计算 bag of words 的 loss; 
        #     bag_word_weight * input 得到的结果向量维度为 [batch_size, 21128]
        #     经 torch.sum 处理后, 维度为 [batch_size], 表示一个 batch 中的句子的 bow loss
        #     经 torch.mean 处理后即得到一个 loss 值, 表示一个 batch 中的句子的平均 bow loss
        bow_loss = torch.mean(-torch.sum(bag_word_weight * input, dim=1))
        return bow_loss

    def forward(self,
                encoder_input_ids, encoder_attention_mask, encoder_labels,
                decoder_input_ids, decoder_attention_mask, decoder_labels,
                bag_word_weight):
        """
        模型的数据输入含以下 7 项:
        encoder_input_ids: 原始输入文本的 token id 列表
        encoder_attention_mask: 值均为 1, 维度与以上相同
        encoder_labels: 记录那些会被 mask 掉的 token id (后续供预测时校验)
                        注意-jy-IMP: encoder 端的 mask 仅仅在该参数中得到体现;
        decoder_input_ids: 原始输入文本的 token id 列表 (同 encoder_input_ids)
        decoder_attention_mask: 一段文本的注意力权重 mask 矩阵 (其中矩阵每一行的首末位置均
                                为 1, 对角线位置为 0, 即表明 special token 的相关注意力得分
                                均被 mask 掉, 其它 token 自身的注意力确保一定不会被 mask)
                                注意-jy-IMP: decoder 端的 mask 仅仅在该参数中得到体现
        decoder_labels: 记录 decoder 端要预测的 token id (除 special token 不需要预测外, 其
                        它 token 均需要预测, 因为 mask 掉的其实是针对注意力矩阵中的注意力得
                        分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩阵, 实际上 
                        decoder 的输入的 id 不会被 mask)
        bag_word_weight: 维度为: [batch_size, 词表大小], 存放一个句子中的 token id 在词表的
                         对应位置的权重; 总权重和为 1, 因此每个 token 的权重为 1/len(sentence)
        """
        # jy: self.lm 为: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)       
        #     调用该类返回得到的结果为 MaskedLMOutput 类, 包含如下属性:
        #     loss: tensor(2.0674, device='cuda:0', grad_fn=<NllLossBackward0>)
        #     logits: 维度为 [batch_size, max_len, 21128]
        #     hidden_states: 长度为 13 的元组, 元组中存储每一层输出的向量, 维度为 [batch_size, max_len, 768]
        #     attentions: None
        lm_out: MaskedLMOutput = self.lm(
            encoder_input_ids, encoder_attention_mask,
            labels=encoder_labels,
            output_hidden_states=True,
            return_dict=True
        )

        # jy: 取 cls 最后一层隐层
        #     lm_out.hidden_states[-1] 维度为: [batch_size, max_len, 768]
        #     取值后的 cls_hiddens 维度为: [batch_size, 768]
        #     即: 即获取第一个 token ([CLS]) 对应的最后一层 embedding
        #     如果需要取 other token 的 embedding, 则也采用该方式提取,
        #     如取所有 other token 的 embedding: lm_out.hidden_states[-1][:, 1:-1]
        cls_hiddens = lm_out.hidden_states[-1][:, 0]


        # jy-update: 更新 cls_hiddens 向量, 使其融入 other token 信息进行加权处理
        """
        ot_hiddens = lm_out.hidden_states[-1][:, 1:]
        # max-pooling
        ot_hiddens_pooling, _ = torch.max(ot_hiddens, dim=1)
        # avg-pooling
        #ot_hiddens_pooling = torch.sum(ot_hiddens, dim=1) / ot_hiddens.size(1)
        weight = 0.5
        sent_embedding = weight * cls_hiddens + (1-weight) * ot_hiddens_pooling
        cls_hiddens = sent_embedding
        """


        # jy: 调用 decoder_mlm_loss 方法, 计算 decoder 端的 mlm 的 loss
        mlm_loss = self.decoder_mlm_loss(cls_hiddens, decoder_input_ids, decoder_attention_mask, decoder_labels)

        # jy: ot_embedding 方法的主要作用是对 other token 的 embedding 进行 max-pooling 操作,
        #     提取一个句子中 other token 的特征, 得到的结果向量作为句子的 bag of words 特征向
        #     量, 维度为: [batch_size, 21128]
        #     lm_out.logits[:, 1:] 的维度为: [batch_size, max_len-1(即不含 [cls]), 21128]
        #     encoder_attention_mask[:, 1:] 的维度为: [batch_size, max_len-1(即不含 [cls])]
        ot_embedding = self.ot_embedding(lm_out.logits[:, 1:], encoder_attention_mask[:, 1:])
        # jy: 调用 decoder_ot_loss 方法, 计算 bag of word 特征向量的 loss
        bow_loss = self.decoder_ot_loss(ot_embedding, bag_word_weight=bag_word_weight)

        # jy: bow_loss_weight 参数值默认为 0.1; 以下即计算总损失
        loss = mlm_loss + self.model_args.bow_loss_weight * bow_loss + lm_out.loss

        return (loss, )



    def mlm_loss(self, hiddens, labels):
        """
        对 hiddens 向量进行线性转换, 转换后得到的向量维度中, 每个位置上的 token 对应的
        向量维度与词表大小相同, 因此可基于该向量与该位置上的真实 token id 计算预测 loss
        传入参数: 
        hiddens: 维度为 [batch_size, max_len, 768]
        labels: 维度为 [batch_size, max_len], 记录 decoder 端要预测的 token id
                (除 special token 不需要预测外, 其它 token 均需要预测, 因为 mask 掉的其实是针
                对注意力矩阵中的注意力得分; 即是基于 mask 掉 token 后获取对应的注意力 mask 矩
                阵, 实际上 decoder 的输入的 id 不会被 mask)
        """
        # jy: self.lm 为: 已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        #     self.lm.cls 为已初始化的 BertOnlyMLMHead 类, 该类作用: 对 hiddens 向量进行线性转换 (从
        #     [batch_size, max_len, 768] 维转换为 [batch_size, max_len, 21128] 维)、激活函数激
        #     活、layernorm 处理, 因此得到的 pred_scores 维度为 [batch_size, max_len, 21128]
        pred_scores = self.lm.cls(hiddens)
        # jy: 计算线性转换后的 token id 向量分布与 labels 标签的 token id 的交叉熵损失得分
        masked_lm_loss = self.cross_entropy(
            # jy: 维度为 [batch_size * max_len, 21128]
            pred_scores.view(-1, self.lm.config.vocab_size),
            # jy: 维度为 [batch_size * max_len]
            labels.view(-1)
        )
        return pred_scores, masked_lm_loss

    def save_pretrained(self, output_dir: str):
        self.lm.save_pretrained(output_dir)

    @classmethod
    def from_pretrained(
            cls, model_args: ModelArguments,
            *args, **kwargs
    ):
        """
        自定义该类的 from_pretrained 方法;
        调用该方法时传入的参数:
        model_args: 模型参数类
        args: 包含模型路径的元组
        """
        # jy: 得到一个已初始化的 BertForMaskedLM 类 (/transformers/models/bert/modeling_bert.py 中)
        hf_model = AutoModelForMaskedLM.from_pretrained(*args, **kwargs)
        # jy: 初始化当前模型类并返回
        model = cls(hf_model, model_args)
        return model


