import random
from copy import deepcopy
from dataclasses import dataclass
from datasets import Dataset, load_dataset, concatenate_datasets

import torch.utils.data.dataset
from pretrain.utils import tensorize_batch
from transformers import DataCollatorForWholeWordMask
import os

# jy: 该类继承自 /torch/utils/data.py 中的 Dataset 类
class DatasetForPretraining(torch.utils.data.Dataset):
    """
    参考 /FlagEmbedding/baai_general_embedding/retromae_pretrain/data.py
    直接从 json 文件中加载数据 (无需预先处理后保存到本地磁盘, 避免内存占用过多);
    """
    def __init__(self, data_dir, cache_dir):
        """
        初始化时会传入以下两个参数:
        data_dir: 数据所在目录或具体文件 (数据文件中的数据格式为: {"text": "xxxx"})
        cache_dir: 数据缓存路径
        """
        self.cache_dir = cache_dir
        # jy: 如果传入的数据路径是一个文件夹
        if os.path.isdir(data_dir):
            datasets = []
            for file in os.listdir(data_dir):
                print(f"Loading {file}")
                file = os.path.join(data_dir, file)
                datasets.append(self.load_dataset(file))
            self.dataset = concatenate_datasets(datasets)
        # jy: 传入的数据路径为一个文件, 则直接从指定路径中加载数据
        else:
            print(f"Loading {data_dir}")
            # jy: 调用 load_dataset 方法加载数据(会优先判断是否从缓存中加载)
            self.dataset = self.load_dataset(data_dir)

    def load_dataset(self, file):
        """
        加载数据: 优先考虑从缓存路径中加载, 没有则从数据文件中加载
        """
        # jy: jsonl 或 json 格式的数据的加载方式
        if file.endswith('.jsonl') or file.endswith('.json'):
            return load_dataset('json', data_files=file, cache_dir=self.cache_dir)['train']
        # jy: 文件夹/目录的加载方式
        elif os.path.isdir(file):
            return Dataset.load_from_disk(file)
        else:
            raise NotImplementedError(f"Not support this file format:{file}")

    def __getitem__(self, item):
        return self.dataset[item]['text']

    def __len__(self):
        return len(self.dataset)



# jy: 该类继承自 DataCollatorForWholeWordMask 类(/transformers/data/data_collator.py 包中)
@dataclass
class RetroMAECollator(DataCollatorForWholeWordMask):
    max_seq_length: int = 512
    encoder_mlm_probability: float = 0.15
    decoder_mlm_probability: float = 0.15

    def __call__(self, examples):
        """
        以下代码逻辑是按 examples 为如下参数进行构建:
        examples: 一个列表, 列表中元素为一个 dict, 格式如下:
                 {'token_ids': 长度不定的 token id 列表 (可能大于 512 个值) }

        需修改为 examples 为一个 text 列表的逻辑
        """
        input_ids_batch = []
        attention_mask_batch = []
        encoder_mlm_mask_batch = []
        decoder_labels_batch = []
        decoder_matrix_attention_mask_batch = []

        tgt_len = self.max_seq_length - self.tokenizer.num_special_tokens_to_add(False)


        # jy: 注意, 该方法不支持 pdb 调试(因为数据处理为分布式处理), 否则运行过程中会报错
        #import pdb; pdb.set_trace()
        for e in examples:
            # jy:【原代码逻辑】
            #e_trunc = self.tokenizer.build_inputs_with_special_tokens(e['token_ids'][:tgt_len])
            # jy:【新代码逻辑】
            e_trunc = self.tokenizer.encode(e, max_length=self.max_seq_length, truncation=True)

            tokens = [self.tokenizer._convert_id_to_token(tid) for tid in e_trunc]

            # jy: 
            self.mlm_probability = self.encoder_mlm_probability
            text_encoder_mlm_mask = self._whole_word_mask(tokens)

            self.mlm_probability = self.decoder_mlm_probability
            mask_set = []
            for _ in range(min(len(tokens), 256)):
                mask_set.append(self._whole_word_mask(tokens))

            text_matrix_attention_mask = []
            for i in range(len(tokens)):
                idx = random.randint(0, min(len(tokens), 256) - 1)
                text_decoder_mlm_mask = deepcopy(mask_set[idx])
                text_decoder_mlm_mask[i] = 1
                text_matrix_attention_mask.append(text_decoder_mlm_mask)

            input_ids_batch.append(torch.tensor(e_trunc))
            attention_mask_batch.append(torch.tensor([1] * len(e_trunc)))
            e_trunc[0] = -100
            e_trunc[-1] = -100
            decoder_labels_batch.append(torch.tensor(e_trunc))

            encoder_mlm_mask_batch.append(torch.tensor(text_encoder_mlm_mask))
            decoder_matrix_attention_mask_batch.append(1 - torch.tensor(text_matrix_attention_mask))


        # jy: 调用 ./utils.py 中的 tensorize_batch 函数, 对一个 batch 的向量进行 padding
        #     处理, 默认左对齐;
        input_ids_batch = tensorize_batch(input_ids_batch, self.tokenizer.pad_token_id)
        attention_mask_batch = tensorize_batch(attention_mask_batch, 0)
        origin_input_ids_batch = input_ids_batch.clone()
        encoder_mlm_mask_batch = tensorize_batch(encoder_mlm_mask_batch, 0)
        encoder_input_ids_batch, encoder_labels_batch = self.torch_mask_tokens(
            input_ids_batch, encoder_mlm_mask_batch)
        decoder_labels_batch = tensorize_batch(decoder_labels_batch, -100)
        matrix_attention_mask_batch = tensorize_batch(decoder_matrix_attention_mask_batch, 0)

        batch = {
            "encoder_input_ids": encoder_input_ids_batch,
            "encoder_attention_mask": attention_mask_batch,
            "encoder_labels": encoder_labels_batch,
            # jy: batch 中的每一项为原始输入的文本的 token id 列表 (首尾为 special token id)
            "decoder_input_ids": origin_input_ids_batch,
            "decoder_attention_mask": matrix_attention_mask_batch,  # [B,L,L]
            "decoder_labels": decoder_labels_batch,
        }

        return batch


# jy: 该类继承自 DataCollatorForWholeWordMask 类(/transformers/data/data_collator.py 中)
@dataclass
class DupMAECollator(DataCollatorForWholeWordMask):
    """
    初始化该类时会传入四个参数(初始化方法在父类中定义): 
    tokenizer
    encoder_mlm_probability
    decoder_mlm_probability
    max_seq_length
    """
    # jy: 以下参数值会被初始化时传入的覆盖掉(如果初始化时有传入对应参数)
    max_seq_length: int = 512
    encoder_mlm_probability: float = 0.15
    decoder_mlm_probability: float = 0.15

    def __call__(self, examples):
        """
        【原代码逻辑】按 examples 为如下参数进行构建:
                      examples: 一个列表, 列表中元素为一个 dict, 格式如下:
                      {'token_ids': 长度不定的 token id 列表 (可能大于 512 个值) }
        【新代码逻辑】当前已修改为新代码逻辑
                      examples 是一个 text 列表
        """
        input_ids_batch = []
        attention_mask_batch = []
        encoder_mlm_mask_batch = []
        decoder_labels_batch = []
        decoder_matrix_attention_mask_batch = []
        bag_word_weight = []


        # jy: 注意, 该方法不支持 pdb 调试(因为数据处理为分布式处理), 否则运行过程中会报错
        #     因此, 调试时只能基于 print 语句
        #import pdb; pdb.set_trace()
        # jy: self.tokenizer.num_special_tokens_to_add(False) 的值为 2 (表明有 2 个 special token)
        #     即 tgt_len 表示预留 special token 之后的文本最大长度
        tgt_len = self.max_seq_length - self.tokenizer.num_special_tokens_to_add(False)
        for e in examples:
            # jy:【原代码逻辑】 
            #e_trunc = self.tokenizer.build_inputs_with_special_tokens(e['token_ids'][:tgt_len])
            # jy:【新代码逻辑】
            #     进行 tokenize, 得到 token 的 id 列表 (会在句子前后添加 2 个 special token)
            # jy: e_trunc[1:-1] 即原有效句子的 token id (不加 special token; 且超长会截断)
            e_trunc = self.tokenizer.encode(e, max_length=self.max_seq_length, truncation=True)
            # jy: e_trunc[1:-1]: 句子原文本 token id 列表, 其长度会等于 tgt_len
            #     e_trunc[0]:  101 (即 [CLS] 对应的 token id)
            #     e_trunc[-1]: 102 (即 [SEP] 对应的 token id)
            #print(e_trunc[1:-1], " ==== ", e_trunc[0], " ==== ", e_trunc[-1])
            #print("e_trunc[1:-1] 的长度等于 tgt_len: ", len(e_trunc[1:-1]) == tgt_len)

            # jy: 将 token id 转换为 token
            tokens = [self.tokenizer._convert_id_to_token(tid) for tid in e_trunc]
            # jy: ['[CLS]', '1', '.', '金', '属', '丝', '绞', '线', '压', '模', '装', '置', ',',
            #      '其', '特', '征', '在', '于', ',', '压', '模', '装', '置', '包', '括', '横',
            #      '向', '压', '膜', '组', '件', '[SEP]']
            #print(tokens)


            # jy: 设置 encoder 端输入的 mask ratio
            self.mlm_probability = self.encoder_mlm_probability
            # jy: _whole_word_mask 方法在父类中的定义; 会基于 self.mlm_probability 进行 mask
            text_encoder_mlm_mask = self._whole_word_mask(tokens)
            # jy: 与句子 token id 等长的列表, 其中为 1 的值表示对应位置需要 mask (首尾的
            #     special token 不会进行 mask)
            #     [0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
            #      1, 0, 1, 1, 1, 0, 0, 0, 0, 0]
            #print(text_encoder_mlm_mask)

            # jy: decoder 端是对 attention 矩阵进行 mask 操作, 以下即构造该矩阵;
            self.mlm_probability = self.decoder_mlm_probability
            # jy: 生成至多 256 次 mask 结果 (后续会多次随机取一个使用);
            mask_set = []
            for _ in range(min(len(tokens), 256)):
                mask_set.append(self._whole_word_mask(tokens))
                #print(mask_set[-1])
            text_matrix_attention_mask = []
            # jy: 遍历 tokens 列表中的逐个位置的 token
            for i in range(len(tokens)):
                idx = random.randint(0, min(len(tokens), 256) - 1)
                # jy: text_decoder_mlm_mask 为 decoder 端的 mask 矩阵
                text_decoder_mlm_mask = deepcopy(mask_set[idx])
                # jy: 使得后续添加到 text_matrix_attention_mask 矩阵中的
                #     主对角线部分的位置均为 1 (后续会对数值进行取反, 即
                #     原先为 0 的变为 1, 原先为 1 的变为 0; 实现的逻辑就
                #     是: 当前为 1 的位置后续经取反后对应的该位置的注意力
                #     是生效的, 因为后续该位置的值取反后为 0, 不会被 mask
                #     处理, 即实现单词自身的注意力不被 mask、首末 special
                #     token 的注意力均被 mask 掉, 因为经后续取反后, 原先该
                #     矩阵中每一行的首末位置均为 0 就会变为均为 1, 表明要
                #     mask 掉此部分的注意力得分)
                text_decoder_mlm_mask[i] = 1
                text_matrix_attention_mask.append(text_decoder_mlm_mask)
                # jy: 输出该 mask 矩阵进行查看
                #print(text_matrix_attention_mask[-1])
            # jy: 输出以上矩阵时的辅助分割线(方便查看)
            #print("-" * 66)

            # jy: input_ids_batch 记录一个句子对应的 token id 列表
            input_ids_batch.append(torch.tensor(e_trunc))
            # jy: 每个句子对应 attention_mask (值均为 1) 加入到 attention_mask_batch 列表
            attention_mask_batch.append(torch.tensor([1] * len(e_trunc)))
            #print(attention_mask_batch[-1])
            e_trunc[0] = -100
            e_trunc[-1] = -100
            # jy: decoder_labels_batch 记录 decoder 端要预测的 token id (除 special token 不需
            #     要预测外, 其它 token 在 decoder 端都需要预测, 因为 decoder 端最终是针对注意力
            #     得分矩阵进行 mask, 而不是具体的 token)
            decoder_labels_batch.append(torch.tensor(e_trunc))

            encoder_mlm_mask_batch.append(torch.tensor(text_encoder_mlm_mask))
            # jy: 查看原矩阵数值
            #print(torch.tensor(text_matrix_attention_mask))
            # jy: 对以上的 text_matrix_attention_mask 所构造的矩阵中的数值进行取反, 得到的新矩阵
            #     为一段文本的注意力权重 mask 矩阵 (其中矩阵每一行的首末位置均为 1, 对角线位置为
            #     0, 即表明 special token 的相关注意力得分均被 mask 掉, 其它 token 自身的注意力确
            #     保一定不会被 mask), 将其加入 decoder_matrix_attention_mask_batch
            decoder_matrix_attention_mask_batch.append(1 - torch.tensor(text_matrix_attention_mask))
            # jy: 查看取反后的注意力 mask 矩阵数值
            #print("-" * 66)
            #print(decoder_matrix_attention_mask_batch[-1])

            # jy: 基于词表个数初始化 weight 向量
            weight = torch.zeros(size=(self.tokenizer.vocab_size,))
            # jy: 21128, 
            #print(self.tokenizer.vocab_size, " === ", weight)
            # jy:【原代码逻辑】
            #for t in e['token_ids'][:tgt_len]:
                #weight[t] = 1 / len(e['token_ids'][:tgt_len])
            # jy:【新代码逻辑】
            #     遍历句子文本中的 token id, 将该 id 对应的词的所在 weight 的位置设置
            #     相应权重, 权重值为: 文本长度的倒数 (即使得所有词的总权重和为 1) 
            for t in e_trunc[1:-1]:
                weight[t] = 1 / len(e_trunc[1:-1])
            # jy: 维度为 [1, 21128]
            #print(weight.shape)
            # jy: 维度为 [21128]
            #print(weight.unsqueeze(0).shape)
            bag_word_weight.append(weight.unsqueeze(0))


        # jy: 一个 batch 的输入文本的 token id 结果(含首尾的 special token)
        #     维度 [batch_size, max_len]
        input_ids_batch = tensorize_batch(input_ids_batch, self.tokenizer.pad_token_id)
        # jy: 值均为 1, 维度与以上相同
        attention_mask_batch = tensorize_batch(attention_mask_batch, 0)
        # jy: 原始输入文本的 token id 列表;
        origin_input_ids_batch = input_ids_batch.clone()
        # jy: encoder 端需要 mask 掉的位置
        encoder_mlm_mask_batch = tensorize_batch(encoder_mlm_mask_batch, 0)
        # jy: encoder_labels_batch 记录那些会被 mask 掉的 token id (后续供预测时校验)
        #     encoder_input_ids_batch 同 input_ids_batch
        encoder_input_ids_batch, encoder_labels_batch = self.torch_mask_tokens(
            input_ids_batch, encoder_mlm_mask_batch)
        # jy: 均为 True
        #print(encoder_input_ids_batch == input_ids_batch)
        decoder_labels_batch = tensorize_batch(decoder_labels_batch, -100)
        matrix_attention_mask_batch = tensorize_batch(decoder_matrix_attention_mask_batch, 0)
        # jy: 维度为: [batch_size, 词表大小], 存放一个句子中的 token id 在词表的对应位置的权重
        #     总权重和为 1, 因此每个 token 的权重为 1/len(sentence)
        bag_word_weight = torch.cat(bag_word_weight, dim=0)

        batch = {
            # jy: 原始输入文本的 token id 列表, 同 input_ids_batch
            "encoder_input_ids": encoder_input_ids_batch,
            # jy: 值均为 1, 维度与以上相同
            "encoder_attention_mask": attention_mask_batch,
            # jy: 记录那些会被 mask 掉的 token id (后续供预测时校验)
            #     注意-jy-IMP: encoder 端的 mask 仅仅在该参数中得到体现;
            "encoder_labels": encoder_labels_batch,
            # jy: 原始输入文本的 token id 列表, 同 input_ids_batch
            "decoder_input_ids": origin_input_ids_batch,
            # jy: 一段文本的注意力权重 mask 矩阵 (其中矩阵每一行的首末位置均为 1, 对角线位置为
            #     0, 即表明 special token 的相关注意力得分均被 mask 掉, 其它 token 自身的注意力确
            #     保一定不会被 mask)
            #     注意-jy-IMP: decoder 端的 mask 仅仅在该参数中得到体现
            "decoder_attention_mask": matrix_attention_mask_batch,  # [B,L,L]
            # jy: 记录 decoder 端要预测的 token id (除 special token 不需要预测外, 其它 token 均
            #     需要预测, 因为 mask 掉的其实是针对注意力矩阵中的注意力得分; 即是基于 mask 掉
            #     token 后获取对应的注意力 mask 矩阵, 实际上 decoder 的输入的 id 不会被 mask)
            "decoder_labels": decoder_labels_batch,
            # jy: 维度为: [batch_size, 词表大小], 存放一个句子中的 token id 在词表的对应位置的权重
            #     总权重和为 1, 因此每个 token 的权重为 1/len(sentence)
            "bag_word_weight": bag_word_weight
        }

        return batch

