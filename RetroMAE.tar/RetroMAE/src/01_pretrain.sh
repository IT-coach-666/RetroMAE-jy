
#export CUDA_VISIBLE_DEVICES=0,2
export CUDA_VISIBLE_DEVICES=2

# number of gpus
#num_gpu=2
num_gpu=1

# jy: 可选值: retromae  dupmae
pretrain_method=dupmae
#pretrain_method=retromae

# jy: 基础模型 (如 bert-base-chinese、bert-base-uncased)
model_name_or_path=/home/huangjiayue/jy_model/pretrain_model_bert_cn/

# jy: 模型输出路径
output_dir=pretrain_output_${pretrain_method}

# 1) version-1: 存在中间转换过程, 数量量大时存在 OOM 问题
#data_dir=/home/huangjiayue/28_RetroMAE/RetroMAE/examples/pretrain/jy_pretrain_data/msmarco_passage/
#data_dir=/home/huangjiayue/28_RetroMAE/RetroMAE/examples/pretrain/jy_pretrain_data/patent_passage-test/
# 2) version-2: 不存在 OOM 问题
# 测试数据
#data_dir=/home/huangjiayue/27_flag-embedding/FlagEmbedding/jy-pretrain-data/train-test.json
data_dir=./train-data.json
# 真实预训练数据
#data_dir=/mnt/nas/old_project_before_2022/patent_data_cn/pretrain-data-ALL/all-pretrain-data.json

#max_len=512
max_len=32

do_train=True
#do_train=False
epoch=20

# batch_size 为 24 时基本已经打满
#batch_size=24
#batch_size=12
batch_size=4

#dataloader_num_workers=64
dataloader_num_workers=1
#dataloader_num_workers=32

#cache_dir=None
#cache_dir=/mnt/nas/huangjiayue_dir/data-retroMAE/
cache_dir=./cache-tmp/


# =================== jy-version-1 ==========================
# jy: 即运行 ./src/pretrain/run.py 脚本
#:<<!
python -m torch.distributed.launch --nnodes 1 --nproc_per_node ${num_gpu} \
--use-env \
-m pretrain.run \
--output_dir ${output_dir} \
--data_dir ${data_dir} \
--do_train ${do_train} \
--model_name_or_path ${model_name_or_path} \
--remove_unused_columns False \
--per_device_train_batch_size ${batch_size} \
--max_seq_length ${max_len} \
--warmup_ratio 0.1 \
--cache_dir ${cache_dir} \
--learning_rate 1e-4 \
--num_train_epochs ${epoch} \
--overwrite_output_dir True \
--dataloader_num_workers ${dataloader_num_workers} \
--weight_decay 0.01 \
--encoder_mlm_probability 0.3 \
--decoder_mlm_probability 0.5 \
--fp16 True \
--save_steps 2000000 \
--pretrain_method ${pretrain_method}
#!

# =================== jy-version-2 ==========================
:<<!
torchrun --nproc_per_node ${num_gpu} \
-m pretrain.run \
--output_dir ${output_dir} \
--data_dir ${data_dir} \
--do_train ${do_train} \
--model_name_or_path ${model_name_or_path} \
--remove_unused_columns False \
--per_device_train_batch_size ${batch_size} \
--max_seq_length 512 \
--warmup_ratio 0.1 \
--cache_dir ${cache_dir} \
--learning_rate 1e-4 \
--num_train_epochs ${epoch} \
--overwrite_output_dir True \
--dataloader_num_workers ${dataloader_num_workers} \
--weight_decay 0.01 \
--encoder_mlm_probability 0.3 \
--decoder_mlm_probability 0.5 \
--fp16 True \
--save_steps 2000000 \
--pretrain_method ${pretrain_method}
!



