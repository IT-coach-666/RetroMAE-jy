
# Finetune-UNDO (未跑过, 而是用 SimCSE 代替)
output_dir=./finetune_out
model_name_or_path=Shitao/RetroMAE


python -m torch.distributed.launch --nproc_per_node 8 \
-m bi_encoder.run \
--output_dir ${output_dir} \
--model_name_or_path ${model_name_or_path} \
--do_train  \
--corpus_file ./data/BertTokenizer_data/corpus \
--train_query_file ./data/BertTokenizer_data/train_query \
--train_qrels ./data/BertTokenizer_data/train_qrels.txt \
--neg_file ./data/train_negs.tsv 



