# =========================== 项目说明 ============================
"""
conda activate retroMAE   (虚拟环境 python 版本为 3.8.0)


虚拟环境中的相关依赖包:
accelerate               0.22.0
aiohttp                  3.8.5
aiosignal                1.3.1
async-timeout            4.0.3
attrs                    23.1.0
certifi                  2023.7.22
charset-normalizer       3.2.0
click                    8.1.7
cmake                    3.27.4.1
datasets                 1.18.3
dill                     0.3.7
faiss-gpu                1.7.2
filelock                 3.12.3
frozenlist               1.4.0
fsspec                   2023.6.0
huggingface-hub          0.16.4
idna                     3.4
Jinja2                   3.1.2
joblib                   1.3.2
lit                      16.0.6
MarkupSafe               2.1.3
mpmath                   1.3.0
multidict                6.0.4
multiprocess             0.70.15
networkx                 3.1
nltk                     3.8.1
numpy                    1.24.4
nvidia-cublas-cu11       11.10.3.66
nvidia-cuda-cupti-cu11   11.7.101
nvidia-cuda-nvrtc-cu11   11.7.99
nvidia-cuda-runtime-cu11 11.7.99
nvidia-cudnn-cu11        8.5.0.96
nvidia-cufft-cu11        10.9.0.58
nvidia-curand-cu11       10.2.10.91
nvidia-cusolver-cu11     11.4.0.1
nvidia-cusparse-cu11     11.7.4.91
nvidia-nccl-cu11         2.14.3
nvidia-nvtx-cu11         11.7.91
packaging                23.1
pandas                   2.0.3
pip                      23.2.1
psutil                   5.9.5
pyarrow                  13.0.0
pysenal                  0.1.2
python-dateutil          2.8.2
pytz                     2023.3
PyYAML                   6.0.1
regex                    2023.8.8
requests                 2.31.0
safetensors              0.3.3.post1
setuptools               68.0.0
six                      1.16.0
sympy                    1.12
tokenizers               0.13.3
torch                    2.0.1
tqdm                     4.66.1
transformers             4.32.1
triton                   2.0.0
typing_extensions        4.7.1
tzdata                   2023.3
urllib3                  2.0.4
w3lib                    2.1.2
wheel                    0.38.4
xxhash                   3.3.0
yarl                     1.9.2


以上安装好 transformers 包后, 可将 ./transformers-jy-annotation 中
包含注解的脚本替换到该安装好的包下 (为了防止出错, 可将原脚本备份) 





-----------------------------------------------------------
# 1) 构造预训练数据 ---------------------------------------
-----------------------------------------------------------
# 配置好参数后执行:
python examples/pretrain/03-jy-pretrain-data.py


-----------------------------------------------------------
# 2) 执行预训练过程 ---------------------------------------
-----------------------------------------------------------
cd src
bash 01_pretrain.sh
cd ../


-----------------------------------------------------------
# 3) 执行 fintune -----------------------------------------【UNDO】
-----------------------------------------------------------
cd src
bash 02_finetune.sh
"""


