from datasets import load_dataset, concatenate_datasets
from pysenal import read_jsonline_lazy, read_lines_lazy, read_json
from pysenal import get_chunk, append_jsonlines
import re

import traceback
import time
import unicodedata
from html import unescape
from w3lib.html import remove_tags
from urllib.parse import unquote
import functools
import logging
import os
from difflib import SequenceMatcher
import re
from string import punctuation



bg_tag_1 = "\n背景技术"
bg_tag_2 = "背景技术\n"
inv_tag_1 = "发明内容\n"
inv_tag_2 = "\n发明内容"
shiyong_tag_1 = "实用新型内容\n"
shiyong_tag_2 = "\n实用新型内容"

futu_tag = "\n附图说明\n"
detail_tag = "\n具体实施方式\n"

def remove_num(text):
    pattern = "\[[0-9]{3,4}\]"
    text = re.sub(pattern, "", text)
    return text

def get_backgroud(desc):
    """
    获取 "背景技术"
    """
    desc = remove_num(desc)

    bg_text = ""
    if bg_tag_1 in desc and inv_tag_1 in desc:
        split_ = desc.split(bg_tag_1)
        bg_text = split_[1].split(inv_tag_1)[0]
    elif bg_tag_1 in desc and inv_tag_2 in desc:
        split_ = desc.split(bg_tag_1)
        bg_text = split_[1].split(inv_tag_2)[0]
    elif bg_tag_1 in desc and shiyong_tag_1 in desc:
        split_ = desc.split(bg_tag_1)
        bg_text = split_[1].split(shiyong_tag_1)[0]
    elif bg_tag_1 in desc and shiyong_tag_2 in desc:
        split_ = desc.split(bg_tag_1)
        bg_text = split_[1].split(shiyong_tag_2)[0]

    elif bg_tag_2 in desc and inv_tag_1 in desc:
        split_ = desc.split(bg_tag_2)
        bg_text = split_[1].split(inv_tag_1)[0]
    elif bg_tag_2 in desc and inv_tag_2 in desc:
        split_ = desc.split(bg_tag_2)
        bg_text = split_[1].split(inv_tag_2)[0]
    elif bg_tag_2 in desc and shiyong_tag_1 in desc:
        split_ = desc.split(bg_tag_2)
        bg_text = split_[1].split(shiyong_tag_1)[0]
    elif bg_tag_2 in desc and shiyong_tag_2 in desc:
        split_ = desc.split(bg_tag_2)
        bg_text = split_[1].split(shiyong_tag_2)[0]
    else:
        #print("==" * 44)  
        #print(desc)
        #print("--" * 44)  
        pass
    bg_text = bg_text.replace("\n", "")
    bg_text = bg_text.strip(":：")
    #bg_text = remove_num(bg_text)
    return bg_text

def get_invention_text(desc):
    """
    获取 "发明内容"
    """
    #desc = remove_num(desc)

    inv_text = ""
    if inv_tag_1 in desc and futu_tag in desc:
        split_ = desc.split(inv_tag_1)
        inv_text = split_[1].split(futu_tag)[0]
    elif inv_tag_2 in desc and futu_tag in desc:
        split_ = desc.split(inv_tag_2)
        inv_text = split_[1].split(futu_tag)[0]
    elif shiyong_tag_1 in desc and futu_tag in desc:
        split_ = desc.split(shiyong_tag_1)
        inv_text = split_[1].split(futu_tag)[0]
    elif shiyong_tag_2 in desc and futu_tag in desc:
        split_ = desc.split(shiyong_tag_2)
        inv_text = split_[1].split(futu_tag)[0]

    else:
        print("==" * 44)
        print(desc)
        print("--" * 44)
    return inv_text

def get_detail_text(desc):
    """
    获取 "具体实施方式"
    """
    if detail_tag in desc:
        pass

def clean_text(text):
    text = unicodedata.normalize('NFKC', text)
    # format text such as '%29 and &lt;'
    text = unescape(unquote(text))

    # remove html tag
    #text = _html_tag_regex.sub('', text)
    text = remove_tags(text)

    # remove whitespace
    text = text.replace(' ', '')
    return text

def parse_clean_claim(text_claim):
    split_tag = "\n2."
    split_tag_v2 = "\n2、"
    split_tag_v3 = "\n[2]"
    split_tag_v4 = "。2."
    split_tag_v5 = "[权利要求2]"
    split_tag_v6 = "2.如权利要求1"
    split_tag_v7 = "【权利要求2】"
    split_tag_v8 = "0002.2.根据权利要求1"
    split_tag_v9 = "。2§."
    split_tag_v10 = "。\n"

    first_claim = text_claim
    if split_tag in text_claim:
        first_claim = text_claim.split(split_tag)[0]
    elif split_tag_v2 in text_claim:
        first_claim = text_claim.split(split_tag_v2)[0]
    elif split_tag_v3 in text_claim:
        first_claim = text_claim.split(split_tag_v3)[0]
    elif split_tag_v4 in text_claim:
        first_claim = text_claim.split(split_tag_v4)[0]
    elif split_tag_v5 in text_claim:
        first_claim = text_claim.split(split_tag_v5)[0]
    elif split_tag_v6 in text_claim:
        first_claim = text_claim.split(split_tag_v6)[0]
    elif split_tag_v7 in text_claim:
        first_claim = text_claim.split(split_tag_v7)[0]
    elif split_tag_v8 in text_claim:
        first_claim = text_claim.split(split_tag_v8)[0]
    elif split_tag_v9 in text_claim:
        first_claim = text_claim.split(split_tag_v9)[0]
    elif split_tag_v10 in text_claim:
        first_claim = text_claim.split(split_tag_v10)[0]

    ls_split = first_claim.split("\n")
    ls_split = [text for text in ls_split if len(text) > 10]
    first_claim = "".join(ls_split)


    return first_claim


def get_obj_data(f_name, f_out):
    ls_dict_out = []
    for dict_ in read_jsonline_lazy(f_name):
        if "pid" in dict_:
            abst = dict_["abst"]
            claim = dict_["claim"]
            desc = dict_["desc"]
        elif "patentId" in dict_:
            country = dict_.get("country", "UNK")
            if country != "CN":
                continue
            abst = dict_.get("abst", "")
            claim = dict_.get("clms", "")
            desc = dict_.get("desc", "")

        abst = clean_text(abst)
        abst = abst.replace("\n", "")
        if len(abst) > 50:
            ls_dict_out.append({"text": abst})
        f_c = parse_clean_claim(clean_text(claim))
        if len(f_c) > 50:
            ls_dict_out.append({"text": f_c})
        #import pdb; pdb.set_trace()
        bg_text = get_backgroud(desc)
        if len(bg_text) > 50:
            ls_dict_out.append({"text": bg_text})
        #import pdb; pdb.set_trace()
        #print(ls_dict_out[-3:])
        #print(bg_text)
        #inv_text = get_invention_text(desc)
        #print(inv_text)
        if len(ls_dict_out) >= 100000:
            append_jsonlines(f_out, ls_dict_out)
            ls_dict_out = []
    if ls_dict_out:
        append_jsonlines(f_out, ls_dict_out)



f_data1 = "/mnt/nas/old_project_before_2022/patent_data_cn/cn_2700w.txt"
f_data2 = "/mnt/nas/old_project_before_2022/patent_data_cn/2500w-pid-tacd.json"

f_3 = "/mnt/nas/huangjiayue_dir/semantic_test/doc_ori_top2k_ttl-abst-fc.json"
f_out = "/mnt/nas/old_project_before_2022/patent_data_cn/pretrain-data-ALL/all-pretrain-data.json"


ls_done_pid = []
for idx, dict_ in enumerate(read_jsonline_lazy(f_data1)):
    pid = dict_["patentId"]
    ls_done_pid.append(pid.strip())
    if (idx+1) % 1000000 == 0:
        print("获取完第 %s 个 pid" % (idx+1))
for idx, dict_ in enumerate(read_jsonline_lazy(f_data2)):
    pid = dict_["pid"]
    ls_done_pid.append(pid.strip())
    if (idx+1) % 1000000 == 0:
        print("==获取完第 %s 个 pid" % (idx+1))

ls_dict_out = []
set_done_pid = set(ls_done_pid)
for idx, dict_ in enumerate(read_jsonline_lazy(f_3)):
    pid = dict_["pid"]
    if pid in set_done_pid:
        continue
    abst = dict_["abst"]
    claim = dict_["claim"]
    if len(abst) > 50:
        ls_dict_out.append({"text": abst})
    if len(claim) > 50:
        ls_dict_out.append({"text": claim})
    if len(ls_dict_out) >= 10000:
        append_jsonlines(f_out, ls_dict_out)
        ls_dict_out = []
    if (idx+1) % 1000000 == 0:
        print("处理完第 %s 个 pid" % (idx+1))

if ls_dict_out:
    append_jsonlines(f_out, ls_dict_out)

#get_obj_data(f_data1, f_out)
#get_obj_data(f_data2, f_out)



