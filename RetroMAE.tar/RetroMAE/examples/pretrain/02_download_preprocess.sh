
# jy: bert 预训练所需数据下载 (bert_data) 并预处理 ===========================
:<<!
python preprocess.py --data bert_data \
--tokenizer_name ~/jy_model/bert-base-uncased \
--output_dir pretrain_data/bert_data
!


# jy: 具体下游任务预训练数据下载 (msmarco_passage) 并预处理 ==================
#     该过程会下载数据:
#     https://huggingface.co/datasets/Tevatron/msmarco-passage-corpus/resolve/main/corpus.jsonl.gz
#     下载解压后的文件中每行数据格式如:
#     {"docid": "0", "title": "Introduction", "text": "The presence of communication amid scientific minds was equally important to the success of the Manhattan Project as scientific intellect was. The only cloud hanging over the impressive achievement of the atomic researchers and engineers is what their success truly meant; hundreds of thousands of innocent lives obliterated."}
#     即: 自定义数据需准备成以上形式然后进行处理
:<<!
python preprocess.py --data msmarco_passage \
--tokenizer_name ~/jy_model/bert-base-uncased \
--output_dir jy_pretrain_data/msmarco_passage
!

# jy: 准备好指定格式的数据后直接预处理(无需再次下载): msmarco_passage 示例
:<<!
python preprocess.py --data msmarco_passage \
--data_dir ./test-data-en-10w \
--tokenizer_name ~/jy_model/bert-base-uncased \
--output_dir jy_pretrain_data/msmarco_passage
!

# jy: 自定义专利数据文件处理
#     data_dir 路径下的 json 文件中每行的数据格式: {"docid": "0", "title": "", "text": "abstract/claim/desc"}
:<<!
python preprocess.py --data patent_passage \
--data_dir ./data-3file-patent-3W \
--tokenizer_name ~/jy_model/pretrain_model_bert_cn/ \
--output_dir jy_pretrain_data/patent_passage-test
!

# 全量数据处理 --------------------
#:<<!
python preprocess.py --data patent_passage \
--data_dir /mnt/nas/old_project_before_2022/patent_data_cn/pretrain-data-ALL \
--tokenizer_name ~/jy_model/pretrain_model_bert_cn/ \
--output_dir /mnt/nas/old_project_before_2022/patent_data_cn/jy_pretrain_data/patent_passage
#!








