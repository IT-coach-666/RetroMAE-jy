import argparse
import random
from pathlib import Path

from datasets import load_dataset, concatenate_datasets
from transformers import AutoTokenizer
import sys


def create_passage_data(tokenizer_name: str,
                        max_seq_length: int,
                        data_dir: str = "",
                        short_seq_prob: float = 0.0, cache_dir: str = "./"):
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    target_length = max_seq_length - tokenizer.num_special_tokens_to_add(pair=False)

    def passage_tokenize_function_zh(examples):
        """
        传入数据的格式为(不要求限制文本长度): {"text": "xxx"}
        """
        text = examples['text']
        # jy: 中文分句;
        text = text.replace("\n", "")
        for punct in ["；", ";", "。", "?", "？", "!", "！"]:
            text = text.replace(punct, "%s\n" % punct)
        text = text.strip()
        #sentences = [sent for sent in text.split("\n") if len(sent) > 2]
        sentences = text.split("\n")
        #print("------- ", len(text), text)
        return tokenizer(sentences, add_special_tokens=False, truncation=False, return_attention_mask=False,
                         return_token_type_ids=False)


    def passage_pad_each_line(examples):
        """
        由以下逻辑可看出, 不再有分句逻辑; 即预训练过程没有 NSP ?
        """
        blocks = []
        for sents in examples['input_ids']:
            curr_block = []
            curr_tgt_len = target_length if random.random() > short_seq_prob else random.randint(3,
                                                                                                 target_length)
            for sent in sents:
                if len(curr_block) >= curr_tgt_len:
                    blocks.append(curr_block)
                    curr_block = []
                    curr_tgt_len = target_length if random.random() > short_seq_prob \
                        else random.randint(3, target_length)
                curr_block.extend(sent)
            if len(curr_block) > 0:
                blocks.append(curr_block)
        return {'token_ids': blocks}

    if not data_dir:
        print("ERROR! %s 数据必须指定具体数据文件路径" % data)


    import pdb; pdb.set_trace()
    # jy: 如果 data_dir 为存放 json 文件的目录
    #msmarco = load_dataset(data_dir, cache_dir=cache_dir)
    #msmarco = load_dataset(data_dir, split="test")
    #msmarco = load_dataset(data_dir, split="train", cache_dir=cache_dir)
    # jy: 如果 data_dir 为 json 文件
    msmarco = load_dataset('json', data_files=data_dir)["train"]
    tokenized_msmarco = msmarco.map(passage_tokenize_function_zh, num_proc=12,
                                    remove_columns=["text"])
    # jy: 经过以下 passage_pad_each_line 处理后, 得到的 processed_msmarco 如(其中
    #     passage_pad_each_line["token_ids"][idx] 为一个长度不超过 512 的 token_id 列表):
    processed_msmarco = tokenized_msmarco.map(passage_pad_each_line, num_proc=12,
                                              batched=True,
                                              # jy: 数据量大时 batch size 过大会导致 OOM
                                              #batch_size=None,
                                              batch_size=2,
                                              remove_columns=["input_ids"])
    return processed_msmarco


if __name__ == '__main__':

    #data_dir = "/mnt/nas/old_project_before_2022/patent_data_cn/pretrain-data-ALL"
    data_dir = "/home/huangjiayue/27_flag-embedding/FlagEmbedding/jy-pretrain-data"

    output_dir = "./jy_pretrain_data/patent_passage-test"   
    #output_dir = "/mnt/nas/old_project_before_2022/patent_data_cn/jy_pretrain_data/patent_passage"

    tokenizer_name = "/home/huangjiayue/jy_model/pretrain_model_bert_cn/"
    #tokenizer_name = "/mnt/nas/chaochao_dir/bge-large-zh"

    #cache_dir = "./cache-tmp"
    cache_dir = None

    max_seq_length = 512
    short_seq_prob = 0
    Path(output_dir).mkdir(parents=True, exist_ok=True)


    dataset = create_passage_data(tokenizer_name, max_seq_length,
                                  data_dir, short_seq_prob, cache_dir)
    dataset.save_to_disk(output_dir)


