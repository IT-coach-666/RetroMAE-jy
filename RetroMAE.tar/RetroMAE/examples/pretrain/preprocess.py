import argparse
import random
from pathlib import Path

from datasets import load_dataset, concatenate_datasets
from transformers import AutoTokenizer


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str)
    parser.add_argument("--tokenizer_name", type=str)
    parser.add_argument("--output_dir", type=str)
    parser.add_argument("--data_dir", type=str, default="")
    parser.add_argument("--max_seq_length", type=int, default=512)
    parser.add_argument("--short_seq_prob", type=float, default=0)

    return parser.parse_args()


def create_book_data(tokenizer_name: str,
                     max_seq_length: int,
                     short_seq_prob: float = 0.0):
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    target_length = max_seq_length - tokenizer.num_special_tokens_to_add(pair=False)

    def book_tokenize_function(examples):
        return tokenizer(examples["text"], add_special_tokens=False, truncation=False,
                         return_attention_mask=False,
                         return_token_type_ids=False)

    def book_pad_each_line(examples):
        blocks = []
        curr_block = []

        curr_tgt_len = target_length if random.random() > short_seq_prob else random.randint(3, target_length)
        for sent in examples['input_ids']:
            if len(curr_block) >= curr_tgt_len:
                blocks.append(curr_block)
                curr_block = []
                curr_tgt_len = target_length if random.random() > short_seq_prob \
                    else random.randint(3, target_length)
            curr_block.extend(sent)
        if len(curr_block) > 0:
            blocks.append(curr_block)
        return {'token_ids': blocks}

    bookcorpus = load_dataset('bookcorpus', split='train')
    tokenized_bookcorpus = bookcorpus.map(book_tokenize_function, num_proc=8,
                                          remove_columns=["text"], batched=True)
    processed_bookcorpus = tokenized_bookcorpus.map(book_pad_each_line, num_proc=8, batched=True,
                                                    remove_columns=["input_ids"])
    return processed_bookcorpus


def create_wiki_data(tokenizer_name: str,
                     max_seq_length: int,
                     short_seq_prob: float = 0.0):
    import nltk
    nltk.download('punkt')

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    target_length = max_seq_length - tokenizer.num_special_tokens_to_add(pair=False)

    def wiki_tokenize_function(examples):
        sentences = []
        for sents in examples['sentences']:
            sentences.append(
                tokenizer(sents, add_special_tokens=False, truncation=False, return_attention_mask=False,
                          return_token_type_ids=False)['input_ids'])
        return {"input_ids": sentences}

    def sentence_wiki(examples):
        sentences = nltk.sent_tokenize(examples["text"])
        return {"sentences": sentences}

    def wiki_pad_each_line(examples):
        blocks = []
        for sents in examples['input_ids']:
            curr_block = []
            curr_tgt_len = target_length if random.random() > short_seq_prob else random.randint(3, target_length)
            for sent in sents:
                if len(curr_block) >= curr_tgt_len:
                    blocks.append(curr_block)
                    curr_block = []
                    curr_tgt_len = target_length if random.random() > short_seq_prob \
                        else random.randint(3, target_length)
                curr_block.extend(sent)
            if len(curr_block) > 0:
                blocks.append(curr_block)
        return {'token_ids': blocks}

    wiki = load_dataset("wikipedia", "20200501.en", split="train")
    wiki = wiki.map(sentence_wiki, num_proc=8, remove_columns=["title", "text"])
    tokenized_wiki = wiki.map(wiki_tokenize_function, num_proc=8, batched=True, remove_columns=["sentences"])
    processed_wiki = tokenized_wiki.map(wiki_pad_each_line, num_proc=8, batched=True,
                                        remove_columns=["input_ids"])

    return processed_wiki


def create_passage_data(tokenizer_name: str,
                        max_seq_length: int,
                        data: str,
                        data_dir: str = "",
                        short_seq_prob: float = 0.0):
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    target_length = max_seq_length - tokenizer.num_special_tokens_to_add(pair=False)

    def passage_tokenize_function(examples):
        if len(examples['title']) > 2:
            text = examples['title'] + ' ' + examples['text']
        else:
            text = examples['text']
        # jy: 主要起分句作用
        sentences = nltk.sent_tokenize(text)
        #print("------- ", len(text), text)
        #print("======= ", len(sentences), sentences)
        return tokenizer(sentences, add_special_tokens=False, truncation=False, return_attention_mask=False,
                         return_token_type_ids=False)

    def passage_tokenize_function_zh(examples):
        if len(examples['title']) > 2:
            text = examples['title'] + '。' + examples['text']
        else:
            text = examples['text']
        # jy: 中文分句;
        text = text.replace("\n", "")[:512]
        for punct in ["；", ";", "。", "?", "？", "!", "！"]:
            text = text.replace(punct, "%s\n" % punct)
        text = text.strip()
        #sentences = [sent for sent in text.split("\n") if len(sent) > 2]
        sentences = text.split("\n")
        #print("------- ", len(text), text)
        #print("======= ", len(sentences), sentences)
        #import pdb; pdb.set_trace()
        #print(sentences)
        return tokenizer(sentences, add_special_tokens=False, truncation=False, return_attention_mask=False,
                         return_token_type_ids=False)


    def passage_pad_each_line(examples):
        blocks = []
        for sents in examples['input_ids']:
            curr_block = []
            curr_tgt_len = target_length if random.random() > short_seq_prob else random.randint(3,
                                                                                                 target_length)
            for sent in sents:
                if len(curr_block) >= curr_tgt_len:
                    blocks.append(curr_block)
                    curr_block = []
                    curr_tgt_len = target_length if random.random() > short_seq_prob \
                        else random.randint(3, target_length)
                curr_block.extend(sent)
            if len(curr_block) > 0:
                blocks.append(curr_block)
        return {'token_ids': blocks}

    #import pdb; pdb.set_trace()
    if data == 'msmarco_passage':
        import nltk
        # jy: 该下载过程如果下载一次后, 可注释掉, 防止接口不稳定耗时等待;
        #nltk.download('punkt')
        if data_dir:
            msmarco = load_dataset(data_dir, split="train")
        else:
            msmarco = load_dataset("Tevatron/msmarco-passage-corpus", split="train")
        msmarco = msmarco.remove_columns("docid")
        tokenized_msmarco = msmarco.map(passage_tokenize_function, num_proc=8,
                                        remove_columns=["text", "title"])
    else:
        if not data_dir:
            print("ERROR! %s 数据必须指定具体数据文件路径" % data)
        #msmarco = load_dataset(data_dir, split="test")
        msmarco = load_dataset(data_dir, split="train", cache_dir="/mnt/nas/huangjiayue_dir/data-retroMAE")
        #msmarco = load_dataset(data_dir)
        msmarco = msmarco.remove_columns("docid")
        # jy: 经过以上处理后, 得到的 msmarco 如:
    	'''
    	Dataset({
        	features: ['title', 'text'],
        	num_rows: 30000
    	})
    	'''
        # jy: passage_tokenize_function_zh 处理后得到的 tokenized_msmarco 如 (每个):
    	'''
    	Dataset({
        	features: ['input_ids'],
        	num_rows: 30000
    	})
    	''' 
        tokenized_msmarco = msmarco.map(passage_tokenize_function_zh, num_proc=12,
                                        remove_columns=["text", "title"])
    # jy: 数据量大时, 该过程十分耗内存;
    # jy: 经过以下 passage_pad_each_line 处理后, 得到的 processed_msmarco 如(其中
    #     passage_pad_each_line["token_ids"][idx] 为一个长度不超过 512 的 token_id 列表):
    '''
    Dataset({
        features: ['token_ids'],
        num_rows: 27434
    })
    '''
    processed_msmarco = tokenized_msmarco.map(passage_pad_each_line, num_proc=12,
                                              batched=True, 
                                              #batch_size=None,
                                              batch_size=2,
                                              remove_columns=["input_ids"])

    return processed_msmarco


if __name__ == '__main__':
    args = get_args()
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)

    # jy: 下载 bert 模型中预训练所需要的数据;
    if args.data == 'bert_data':
        print('download and preprocess wiki and bookcorpus:')
        wiki = create_wiki_data(args.tokenizer_name, args.max_seq_length, args.short_seq_prob)
        book = create_book_data(args.tokenizer_name, args.max_seq_length, args.short_seq_prob)
        dataset = concatenate_datasets([book, wiki])
        dataset.save_to_disk(args.output_dir)
    # jy: 下载具体下游任务 (msmarco_passage) 进行预训练时所需要的数据(最终格式同 bert_data)
    #elif args.data == 'msmarco_passage':
    else:
        print('download and preprocess msmarco-passage:')
        #import pdb; pdb.set_trace()
        dataset = create_passage_data(args.tokenizer_name, args.max_seq_length,
                                      args.data, args.data_dir, args.short_seq_prob)
        dataset.save_to_disk(args.output_dir)
    #else:
    #    raise NotImplementedError


