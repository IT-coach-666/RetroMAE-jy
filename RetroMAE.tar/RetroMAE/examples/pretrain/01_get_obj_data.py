from pysenal import read_jsonline_lazy, read_lines_lazy, read_json
from pysenal import get_chunk, append_jsonlines, write_json, append_lines
import re
import random
import os



# 构造成以下格式的数据并记录到文件中: {"docid": "0", "title": "", "text": "连续的片段"}
def get_obj_data(f_name, f_out, para_type):
    """
    para_type: ["tlt_abst", "claim", "desc"]
    """
    ls_dict_out = []
    for idx, dict_ in enumerate(read_jsonline_lazy(f_name)):
        if (idx+1) % 500000 == 0:
            print("处理完第 %s 个数据" % (idx+1))
        if "patentId" in dict_:
            pid = dict_["patentId"]
            tlt = dict_.get("title", "")
            abst = dict_.get("abst", "")
            claim = dict_.get("clms", "")
            desc = dict_.get("desc", "")
        else:
            pid = dict_["pid"]
            tlt = dict_["tlt"]
            abst = dict_["abst"]
            claim = dict_["claim"]
            desc = dict_["desc"]
        if para_type == "tlt_abst":
            # jy: title 与 abst 组合
            if len(abst) <= 20:
                continue
            ls_dict_out.append({"docid": pid, "title": tlt, "text": abst})
            # jy: 不使用 title 版本:
            #ls_dict_out.append({"docid": pid, "title": "", "text": abst})
        if para_type == "claim":
            if len(claim) <= 20:
                continue
            # jy: claim 单独成片段
            ls_dict_out.append({"docid": pid, "title": "", "text": claim})
        if para_type == "desc":
            if len(desc) <= 50:
                continue
            # jy: desc 可能需要分片
            ls_dict_out.append({"docid": pid, "title": "", "text": desc[:512]})
        if len(ls_dict_out) >= 100000:
            append_jsonlines(f_out, ls_dict_out)
            ls_dict_out = []
    if ls_dict_out:
        append_jsonlines(f_out, ls_dict_out)

f_name = "/mnt/nas/old_project_before_2022/patent_data_cn/2500w-pid-tacd.json"
#f_name = "/mnt/nas/old_project_before_2022/patent_data_cn/cn_2700w.txt"
#para_type = "tlt_abst"
para_type = "claim"
#para_type = "desc"
f_out = "/mnt/nas/old_project_before_2022/patent_data_cn/pretrain-data-ALL/patent-%s-para.json" % para_type
get_obj_data(f_name, f_out, para_type=para_type)








